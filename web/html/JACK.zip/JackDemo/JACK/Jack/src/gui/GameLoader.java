package gui;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;


/*
 * @author Elizabeth Hilliard betsy@cs.brown.edu
 * 
 * The GameLoader class finds exisiting games and loads them into the correct
 * files so the server can use them to run a game.
 * 
 * NOTE: Currently you cannot edit these files in the gui. You can, however, 
 * edit them by hand.
 * This feature will be coming soon.
 */
public class GameLoader {
	
	protected JPanel loader;
	protected JTextArea t;
	protected JComboBox c;
	protected File[] files;
	protected String toLoad;
	protected JFrame loaderF;
	
	public GameLoader(){
		
		loader = createLoader();
		
	}
	
	//creates the panel to be able to select an existing game file
	protected JPanel createLoader(){
		
		loader = new JPanel(new FlowLayout());
		c = new JComboBox();
		
		File file = new File("src");

	    files = file.listFiles();
		
	    //looks at all files and finds the game directories
		for (int i = 0; i < files.length;i++){
			//System.out.println(files[i].getName());
			if(files[i].isDirectory()&& files[i].getName().compareTo("auctions")!=0 
					&& files[i].getName().compareTo("valueations")!=0
					&& files[i].getName().compareTo("server")!=0 && files[i].getName().compareTo("clients")!=0 
					&& files[i].getName().compareTo("gui")!=0)
			c.addItem(files[i].getName());
		}
		
		c.addActionListener(new TextSelected());
		JPanel selector = new JPanel(new FlowLayout());
		selector.add(new JLabel("Select a Saved Game: "));
		selector.add(c);
		
		loader.add(selector, BorderLayout.NORTH);
		
		return loader;
	}
	
	//sets the game name to load based on what is selected
	protected class TextSelected implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent e) {
			toLoad = (String) c.getSelectedItem();
		}
	}
	
	
	//may be depreciated
	protected void setGameToLoad(){
		toLoad = (String) c.getSelectedItem();
	}
	/* OLD METHOD
	public boolean loadPackageFiles(String gameNameStr, String packageName){
		boolean success = true;
		File file = new File(System.getProperty("user.dir")+"/src/"+gameNameStr+"/"+packageName);

	    File[] files2 = file.listFiles();
	    
	    for (int i = 0; i < files2.length; i++){
	    	 File currentFile = files2[i];
	    	 File newFile = new File(System.getProperty("user.dir")+"/src/"+packageName+"/"+currentFile.getName());
	    	 currentFile.renameTo(newFile);
	    	 
	    }
	    return success;
		
	}
	*/
}
